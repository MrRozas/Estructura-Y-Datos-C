#include "pregunta_1.h"

region* read_regions(char* filename, int* number_of_registers) { return NULL; }