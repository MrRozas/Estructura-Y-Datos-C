#include "p1_utilities.h"

void sort_countries(country* countries, int number_country_registers);