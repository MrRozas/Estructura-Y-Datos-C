#include "pregunta_5.h"
void sort_countries(country* countries, int number_country_registers) {}