#include "pregunta_4.h"

country* sort_last_day(country* countries, int number_country_registers,
                       int* number_country_registers_last_day) {
  return NULL;
}