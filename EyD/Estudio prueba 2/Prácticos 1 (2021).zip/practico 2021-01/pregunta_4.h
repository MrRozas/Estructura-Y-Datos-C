void swap_numeros(int* numeros, int pos1, int pos2);
