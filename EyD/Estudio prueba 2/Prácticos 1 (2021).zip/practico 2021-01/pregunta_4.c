#include "pregunta_4.h"

void swap_numeros(int* numeros, int pos1, int pos2) {}