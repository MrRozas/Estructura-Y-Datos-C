#include "pregunta_1.h"

char** leer_archivo_texto(char* filename) { return 0; }