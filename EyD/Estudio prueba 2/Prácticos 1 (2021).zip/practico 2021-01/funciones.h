#include <stdio.h>
void print_array_names(char** names, int number);
void print_array_numbers(int* numbers, int number);