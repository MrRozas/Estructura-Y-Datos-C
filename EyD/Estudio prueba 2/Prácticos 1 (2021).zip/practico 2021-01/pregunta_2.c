#include "pregunta_2.h"

#include <stdio.h>
#include <stdlib.h>
int* leer_archivo_numero(char* filename) { return 0; }