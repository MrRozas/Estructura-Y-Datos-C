#include "pregunta_5.h"

void sort_names(char** nombres, int* numeros, int numero_elementos) {}