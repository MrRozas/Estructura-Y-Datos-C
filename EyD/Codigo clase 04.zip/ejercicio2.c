#include <stdio.h>

void invertir(int n);

int main(void)
{	
  int n;
  printf("Ingrese un numero natural: ");
  scanf("%d", &n);
  printf("El numero invertido es: ");
  invertir(n);
}

void invertir(int n)
{
  if(n < 10)
  {
    printf("%d\n", n);
    return;
  }

  printf("%d", n % 10);
  invertir(n/10);
}