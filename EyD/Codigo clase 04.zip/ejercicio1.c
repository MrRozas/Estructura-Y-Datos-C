#include <stdio.h>

int suma(int n);

int main(void)
{	
  int n;
  printf("Ingrese un número natural: ");
  scanf("%d", &n);
  printf("La suma de 1 a %d es %d\n", n, suma(n));
}

int suma(int n)
{
  if(n==0)
    return 0;
  return n + suma(n-1);
}
