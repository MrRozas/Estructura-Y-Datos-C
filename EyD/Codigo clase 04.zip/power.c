#include <stdio.h>

int power(int a, int n);

int main(void)
{	
  int a,n;
  printf("Ingrese una base y la potencia (separada por espacio): ");
  scanf("%d %d", &a, &n);
  printf("%d elevado a %d es: %d\n", a, n, power(a,n));
}


int power(int a, int n)
{
  if(n==0)
    return 1;
  
  return a * power(a, n-1);
}