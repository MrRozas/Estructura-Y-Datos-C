#include <stdio.h>

int fibonacci(int n);

int main(void)
{	
  int n;
  printf("Ingrese un numero natural: ");
  scanf("%d", &n);
  printf("El %d-esimo numero de Fibonacci es: %d\n", n, fibonacci(n));
}


int fibonacci(int n)
{
  if(n==1)
    return 0;
  if(n==2)
    return 1;

  return fibonacci(n-1) + fibonacci(n-2);
}