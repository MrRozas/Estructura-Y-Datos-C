// Busqueda lineal (entrega posicion de x; -1 si es que no esta)
int linear_search(int *arreglo, int N, int x);
// Busqueda Binaria (entrega posicion de x; -1 si es que no esta)
int binary_search(int *arreglo, int N, int x);


