#include <stdio.h>

// ejemplo punteros
int main(void)
{	
  int a = 5;	
  int *p;		

  p = &a;

  printf("El valor almacenado en a es: %d\n", a);
  printf("La direccion de memoria de la variable a es: %p\n", &a);
  printf("La direccion de memoria almacenada en el puntero p es: %p\n", p);
  printf("La direccion de memoria del puntero p es: %p\n", &p);

  return 0;
}
