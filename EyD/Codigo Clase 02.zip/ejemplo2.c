#include <stdio.h>

// ejemplo punteros e indireccion
int main()
{
  int a = 1;
  int *p;
  printf("Contenido de la variable a: %d\n", a);

  p = &a;
  *p = 3;
  printf("Contenido de la variable a: %d\n", a);

  return 0;
}

