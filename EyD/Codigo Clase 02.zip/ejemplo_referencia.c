#include <stdio.h> 

void intercambia(int *p, int *q);

int main(void)
{	
  // ejemplo paso por referencia
  int a = 1;	
  int b = 3;		
  
  printf("Valor de a: %d. Valor de b: %d\n", a, b);	
  intercambia(&a, &b);	
  printf("Valor de a: %d. Valor de b: %d\n", a, b);

  return 0;
}

void intercambia(int *p, int *q)
{	
  int aux;	
  
  aux = *q;	
  *q = *p;	
  *p = aux;	
  printf("Dentro de funcion, a: %d, b:%d\n", *p, *q);
}



