#include <stdio.h> 

//ejemplo simple scanf

int main(void)
{	
  
  int x;	
  printf("Ingresa numero\n");	
  scanf("%d", &x);	
  printf("Numero ingresado: %d\n", x);

  return 0;
}




