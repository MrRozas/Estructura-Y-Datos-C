#include <stdio.h>

//ejemplo scanf y arreglos

int main()
{
  int i, vector[5];
  
  // almacenamos los 5 numeros de entrada en el arreglo vector
  for(i = 0;i < 5; i++)
  {
   printf(" Ingrese el valor %d del vector:",i);
   scanf("%d", &vector[i]); 
  }

  // mostramos el contenido de vector
  printf("Contenido de vector: ");
  for(i = 0;i < 5; i++)
    printf("%d ", vector[i]);

  return 0;
}

