#include <stdio.h> 

void intercambia(int a, int b);

int main(void)
{	
  // ejemplo paso por valor
  int a = 1;	
  int b = 3;		
  
  printf("Valor de a: %d. Valor de b: %d\n", a,b);	
  intercambia(a,b);	
  printf("Valor de a: %d. Valor de b: %d\n", a,b);

  return 0;
}

void intercambia(int a,int b)
{	
  int aux;	
  
  aux = b;	
  b = a;	
  a = aux;	
  printf("Dentro de funcion, a: %d, b:%d\n", a,b);
}


