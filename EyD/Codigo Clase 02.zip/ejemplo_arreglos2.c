#include <stdio.h> 

void llena_arreglo(int arreglo[]);
void suma_2(int *x);
void imprime_arreglo(int arreglo[]);

int main(void)
{	
  int A1[5], A2[5];
  llena_arreglo(A1);	
  llena_arreglo(A2);	
  suma_2(&A1[3]);
  imprime_arreglo(A1);	
  imprime_arreglo(A2);
}

void llena_arreglo(int arreglo[]){	
  for(int i=0; i<5; i++)    arreglo[i]=i;}

void suma_2(int *x)
{*x=*x+2;       x=x+1;	  *x=*x+3;}

void imprime_arreglo(int arreglo[]){	
   for(int i=0; i<5; i++)  printf("%d\t", arreglo[i]);	
   printf("\n");}
