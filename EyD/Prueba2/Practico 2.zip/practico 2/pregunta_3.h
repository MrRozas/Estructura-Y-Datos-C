#include "utilities.h"

void insertar_capacitancia(float valor, lista *l);