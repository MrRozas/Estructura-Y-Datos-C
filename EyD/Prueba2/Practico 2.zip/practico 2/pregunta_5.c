#include "pregunta_5.h"

nodo* eliminar_componente(float valor, char tipo, lista* l) 
{
  return NULL;
}
