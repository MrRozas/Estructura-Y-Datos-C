#include "utilities.h"

int contar_componentes(char tipo, lista* l);