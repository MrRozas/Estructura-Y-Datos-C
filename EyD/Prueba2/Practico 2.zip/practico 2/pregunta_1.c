#include "pregunta_1.h"

lista* crear_tubo() 
{
  return NULL;
}