#include "pregunta_2.h"

void insertar_resistencia(float valor, lista* l) 
{
  
}