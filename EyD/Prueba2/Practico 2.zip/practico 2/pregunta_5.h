#include "utilities.h"

nodo* eliminar_componente(float valor, char tipo, lista* l);