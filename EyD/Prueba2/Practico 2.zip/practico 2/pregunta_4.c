#include "pregunta_4.h"

int contar_componentes(char tipo, lista* l) 
{
  return 0;
}
