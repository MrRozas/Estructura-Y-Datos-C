#include "pregunta_3.h"

void insertar_capacitancia(float valor, lista* l) 
{

}