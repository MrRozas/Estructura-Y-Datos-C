#include "utilities.h"

void insertar_resistencia(float valor, lista* l);