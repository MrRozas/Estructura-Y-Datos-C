#include "libreria1.h"

void funcion1(void)
{
  printf("Soy la funcion 1\n");
}