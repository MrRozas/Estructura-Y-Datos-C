#include "libreria2.h"

void funcion2(void)
{
  printf("Soy la funcion 2\n");
}