#include <stdio.h>

// Otros includes, defines, variables globales, etc...
 
void funcion2(void);

// Declaraciones de otras funciones...