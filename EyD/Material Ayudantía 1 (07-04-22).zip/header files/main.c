#include "libreria1.h"
#include "libreria2.h"

int main() 
{
  funcion1();
  funcion2();

  return 0;
}