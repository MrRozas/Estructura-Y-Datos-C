#include <stdio.h>

// Otros includes, defines, variables globales, etc...
 
void funcion1(void);

// Declaraciones de otras funciones...