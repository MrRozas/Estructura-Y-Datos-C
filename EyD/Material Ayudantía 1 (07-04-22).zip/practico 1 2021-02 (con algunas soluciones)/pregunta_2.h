#include "p1_utilities.h"

country* create_countries_by_date(region* regions, int number_registers,
                                  int* number_country_registers);