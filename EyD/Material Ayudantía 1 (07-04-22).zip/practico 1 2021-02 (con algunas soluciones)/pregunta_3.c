#include "pregunta_3.h"

void swap(country *c1, country *c2) {}