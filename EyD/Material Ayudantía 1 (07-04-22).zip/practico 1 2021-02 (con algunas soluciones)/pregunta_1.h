#include "p1_utilities.h"

region* read_regions(char* filename, int* number_of_registers);