#include "p1_utilities.h"

void swap(country* c1, country* c2);