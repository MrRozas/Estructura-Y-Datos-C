#include "pregunta_1.h"

void swap(pokemon* p1, pokemon* p2) {}