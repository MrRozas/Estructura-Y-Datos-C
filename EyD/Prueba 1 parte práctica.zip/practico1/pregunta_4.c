#include "pregunta_4.h"

pokemon* N_mejores(pokemon* pokemones, int N, int N_resultado) { return NULL; }
