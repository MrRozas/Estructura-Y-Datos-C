#include "pregunta_2.h"

pokemon* leer_archivo(char* filename, int* N) { return NULL; }