#include "utilities.h"

pokemon* ordenar_pokemones(pokemon* pokemones, int N);