#include "utilities.h"

pokemon* N_mejores_generacion(pokemon* pokemones, int N, int N_resultado,
                              int generacion);