#include "utilities.h"

pokemon* leer_archivo(char* filename, int* N);