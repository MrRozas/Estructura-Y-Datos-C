#include "utilities.h"

pokemon* N_mejores(pokemon* pokemones, int N, int N_resultado);