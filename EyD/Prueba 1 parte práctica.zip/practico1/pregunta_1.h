#include "utilities.h"

void swap(pokemon* p1, pokemon* p2);