#include "pregunta_5.h"

pokemon* N_mejores_generacion(pokemon* pokemones, int N, int N_resultado,
                              int generacion) {
  return NULL;
}