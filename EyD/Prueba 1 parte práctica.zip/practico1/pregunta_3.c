#include "pregunta_3.h"

pokemon* ordenar_pokemones(pokemon* pokemones, int N) { return NULL; }