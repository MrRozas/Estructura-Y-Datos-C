#include "utilities.h"

int cantidad_discipulos(investigador* raiz, int ID);