#include "utilities.h"

investigador* investigador_con_mas_discipulos(investigador* raiz);