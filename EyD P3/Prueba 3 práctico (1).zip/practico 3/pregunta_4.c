#include "pregunta_4.h"

/**
 * @brief Obtiene el investigador con más discipulos
 *
 * @param raiz raiz de la jerarquía
 * @return investigador* el investigador que tiene más discipulos
 */

investigador* investigador_con_mas_discipulos(investigador* raiz) {
  return NULL;
}