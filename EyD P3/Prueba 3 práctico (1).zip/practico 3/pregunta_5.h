#include "utilities.h"

int cantidad_de_investigadores_sin_discipulos(investigador* raiz);