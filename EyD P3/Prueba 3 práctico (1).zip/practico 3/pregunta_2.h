#include "utilities.h"

investigador* insertar_investigador(investigador* raiz, int ID, char* nombre,
                                    int ID_maestro);