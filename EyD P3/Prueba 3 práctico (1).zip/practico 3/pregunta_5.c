#include "pregunta_5.h"

/**
 * @brief Función encargada de contar la cantidad de investigadores que no
 * tienen discipulos
 *
 * @param raiz raíz de la jerarquía
 * @return int retorna la cantidad de investigadores que no tienen discipulos.
 */

int cantidad_de_investigadores_sin_discipulos(investigador* raiz) {
  return 0;
}