#include "pregunta_3.h"
/**
 * @brief Cantidad de discipulos de un investigador dado.
 *
 * @param raiz raíz del árbol jerarquizado
 * @param ID ID del investigador sobre el cual se le contarán los discipulos
 * @return int el número de discípulos del investigador dado.
 */

int cantidad_discipulos(investigador* raiz, int ID) {
  return 0;
}