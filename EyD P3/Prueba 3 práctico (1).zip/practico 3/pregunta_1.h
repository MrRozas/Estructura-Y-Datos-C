#include "utilities.h"

investigador* crear_investigador(int ID, char* nombre);